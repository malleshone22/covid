package com.stackroute.bookmarkservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookmarkserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
