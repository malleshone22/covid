export interface Covid {
    id:number;
    state: string;
    confirmed: number;
    deceased: number;
    recovered: number;
    tested: number;
    vaccinated1:number;
    vaccinated2:number;
  }

