import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {FormControl} from '@angular/forms';

@Component({
  selector: 'app-reactive-from',
  templateUrl: './reactive-from.component.html',
  styleUrl: './reactive-from.component.css'
})
export class ReactiveFromComponent implements OnInit {
  constructor(private fb:FormBuilder){}
  ngOnInit(): void {
    this.login=this.fb.group({
      'username':['',[Validators.required,Validators.minLength(3)]],
      'password':['',[Validators.required,Validators.max(5)]]
    }
    )  
  }


  login!:FormGroup;

  // login=new FormGroup(
  //   {
  //      'username':new FormControl('',[Validators.required,Validators.pattern("[a-zA-z]{6}"),Validators.minLength(5)]),
  //      'password':new FormControl('')
  //   }
  //   )

  
onSubmit()
{
  console.log(this.login);
  alert("Succesfully submiteed");
}
}
