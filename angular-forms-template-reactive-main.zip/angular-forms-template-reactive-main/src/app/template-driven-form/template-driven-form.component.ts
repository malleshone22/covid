import { Component } from '@angular/core';

@Component({
  selector: 'app-template-driven-form',
  templateUrl: './template-driven-form.component.html',
  styleUrl: './template-driven-form.component.css'
})
export class TemplateDrivenFormComponent {

  username:string=''
  pwd:string=''
  email:string=''
  onSubmit(frm:any)
  {
console.log(frm.value);
  }
}
