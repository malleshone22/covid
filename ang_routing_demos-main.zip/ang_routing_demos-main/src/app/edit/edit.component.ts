import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DataService } from '../data.service';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrl: './edit.component.css'
})
export class EditComponent implements OnInit {
  id:number=0;
  constructor(private actr:ActivatedRoute,private datas:DataService){}
  ngOnInit(): void {
    this.actr.params.subscribe((data)=>{
      console.log(data);
      this.id=data['id'];
      this.datas.deleteById(this.id).subscribe((data)=>{
        alert('Deleted');
      })

    } )
  }



}
