import { CanDeactivateFn } from '@angular/router';
import { LoginComponent } from './login/login.component';

export const canDeactivatGuard: CanDeactivateFn<LoginComponent> = (component, currentRoute, currentState, nextState) => {
  return component.canExit();
};
