import { Component } from '@angular/core';

@Component({
  selector: 'app-about-cust',
  templateUrl: './about-cust.component.html',
  styleUrl: './about-cust.component.css'
})
export class AboutCustComponent {

}
