import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AboutEmpComponent } from './about-emp.component';

describe('AboutEmpComponent', () => {
  let component: AboutEmpComponent;
  let fixture: ComponentFixture<AboutEmpComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AboutEmpComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AboutEmpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
