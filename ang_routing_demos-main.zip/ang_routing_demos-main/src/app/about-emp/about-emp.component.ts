import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';

@Component({
  selector: 'app-about-emp',
  templateUrl: './about-emp.component.html',
  styleUrl: './about-emp.component.css'
})
export class AboutEmpComponent implements OnInit{
constructor(private data:DataService){}
emp:any;
ngOnInit(){
this.data.getAllEmp().subscribe((data)=>
  this.emp=data
)
}
}
