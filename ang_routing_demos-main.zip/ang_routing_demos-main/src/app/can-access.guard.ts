import { inject } from '@angular/core';
import { CanActivateFn } from '@angular/router';
import { LoginService } from './login.service';

export const canAccessGuard: CanActivateFn = (route, state) => {
  const log=inject(LoginService);
  if(log.isloggedIn)
  {
    return true;
  }
  else
  {
    return false;
  }
};
